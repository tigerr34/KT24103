#include <iostream>
#define MAX_SIZE 5
using namespace std;
 
class Queue{
private:
int queueArray[MAX_SIZE], rear, front;
     
public:
Queue(){

	rear = -1;
	front = -1;
}
     
boolisFull(){

	if(front == 0 && rear == MAX_SIZE - 1){
	return true;
    }

return false;
}
     
boolisEmpty(){
	
	if(front == -1) return true;
	else return false;
}
     
void wQueue(int value){
	
	if(boolisFull()){
	cout << endl<< "Queue is full";
	} 
	
	else {
	if(front == -1) front = 0;
	rear++;
	queueArray[rear] = value;
	cout<<value<<" ";
    }
}

int deQueue(){
int value;
	if(boolisEmpty()){
	cout << "Queue is empty." << endl; return(-1); } 
	
	else { 
		value = queueArray[front];
	 
		if(front >= rear){ 
		front = -1;
		rear = -1;
		}
	
	else {
	front++;
    }
    
	cout<<endl<<value<<" is deleted from queue";
	
	return(value);
    }
}
     
void displayQueue(){ 
	int i;
	
	if(boolisEmpty()) {
	cout<<endl<<"Queue Empty"<<endl;
    }
    
	else {
	cout<<endl<<"Front = "<<front;
	cout<<endl<<"Queue elements : ";
	
	for(i=front; i<=rear; i++)
	cout<<queueArray[i]<<"  ";
	cout<<endl<<"Rear = "<<rear<<endl;
    }
}

};

int main(){

	Queue queueExample;     
	queueExample.deQueue();
	cout<<"Creating queue:"<<endl; queueExample.wQueue(2); queueExample.wQueue(3); queueExample.wQueue(4); queueExample.wQueue(5); queueExample.wQueue(6);
	cout<<"\n";
	queueExample.displayQueue();
	queueExample.deQueue();
	cout<<"\n";
	queueExample.displayQueue();
	return 0;
}
